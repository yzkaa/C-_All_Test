#include<stdio.h>
#include<stdlib.h>
#define MaxSize    100     //ջ���Ԫ�ظ���
int top=-1;     //ջ��ָ��
int count=1;    //·��������
int minlen=MaxSize;     //���·������
int maze_row=0; //��ͼ������.
int maze_colum=0; //��ͼ������.
int set_OK = 0; //һ��flag�����ڼ�������յ��Ƿ�ɹ����á�
char** load_maze(char* file_location);
struct mz
{
    int x;      //·��������
    int y;      //·��������
    int di;     //����
} Stack[MaxSize],Path[MaxSize];     //����ջ�ʹ�����·��������

void mgpath(char** maze)       
{
    int x,y,di,find,k;
    int startX=-1,startY=-1;
    int endX=-1,endY=-1;
    while (1)
    {
        printf("Please set start point(x,y):");
        if(startX<0||startY<0)
            scanf("%d,%d",&startX,&startY);
        if(maze[startY][startX]!='1'){
            printf("Wrong start location,please try again.");
            startX=startY=-1;
            continue;
        }

        printf("Please set end point(x,y):");
        if(endX<0||endY<0)
            scanf("%d,%d",&endX,&endY);
        if(maze[endY][endX]!='1'){
            printf("Wrong end location,please try again.");
            endX=endY=-1;
            continue;
        }
        printf("Set ok");
        break;
    }
    top++;
    Stack[top].x=startX;
    Stack[top].y=startY;
    Stack[top].di=-1;
    maze[startY][startX]='2';        //��ʼ����ջ
    while(top>-1)       //ջ����ʱѭ��
    {
        x=Stack[top].x;
        y=Stack[top].y;
        di=Stack[top].di;
        if(x==endX && y==endY)        //�ҵ��˳��ڣ����·��
        {
            printf("%d: ",count);
            count++;
            for(k=0; k<=top; k++)
            {
                printf("(%d,%d)->",Stack[k].x,Stack[k].y);
            }
            printf("end\n");
            maze[Stack[top].y][Stack[top].x]='1';   //�ø�λ�ñ�Ϊ����·���Ŀ��߽��
            top--;
            x=Stack[top].x;
            y=Stack[top].y;
            di=Stack[top].di;
        }
        find=0;
        // while(di<4 && find==0)      //����һ�����߽��
        // {
        //     di++;
        //     switch(di)
        //     {
        //     case 0:
        //         if(Stack[top].x+1<maze_colum&& find==0){
        //             if(maze[Stack[top].y][Stack[top].x+1] == '1'){
        //                 x=Stack[top].x+1;
        //                 y=Stack[top].y;
        //                 find==1;
        //                 break;
        //             }
        //             if(Stack[top].y+1<maze_colum && find==0){
        //                 if( maze[Stack[top].y+1][Stack[top].x+1] == '1'){
        //                     x=Stack[top].x+1;
        //                     y=Stack[top].y+1;
        //                     find==1;
        //                     break;
        //                 }
        //             }
        //             if(Stack[top].y-1>=0 && find==0){
        //                 if( maze[Stack[top].y-1][Stack[top].x+1] == '1'){
        //                     x = Stack[top].x+1;
        //                     y = Stack[top].y-1;
        //                     find=1;
        //                     break;
        //                 }
        //             }
        //         }
        //         break;   //��
        //     case 1:
        //         if(Stack[top].y+1<maze_row&& find==0){
        //             if( maze[Stack[top].y+1][Stack[top].x] == '1'){
        //                 x=Stack[top].x;
        //                 y=Stack[top].y+1;
        //                 find = 1;
        //                 break;
        //             }
        //             if(Stack[top].x-1>=0 && find==0){
        //                 if( maze[Stack[top].y+1][Stack[top].x-1] == '1'){
        //                     x=Stack[top].x-1;
        //                     y=Stack[top].y+1;
        //                     find = 1;
        //                     break;
        //                 }
        //             }
        //         }
        //         break;   //��
        //     case 2:
        //         if(Stack[top].x-1>=0 && find==0){
        //             if( maze[Stack[top].y][Stack[top].x-1] == '1'){
        //                 x=Stack[top].x-1;
        //                 y=Stack[top].y;
        //                 find =1;
        //                 break;
        //             }
        //             if(Stack[top].y-1>=0 && find==0){
        //                 if( maze[Stack[top].y-1][Stack[top].x-1] == '1'){
        //                     x=Stack[top].x-1;
        //                     y=Stack[top].y-1;
        //                     find =1;
        //                     break;
        //                 }
        //             }
        //         }
        //         break;   //��
        //     case 3:
        //         if(Stack[top].y-1>=0&& find==0){
        //             if( maze[Stack[top].y-1][Stack[top].x] == '1')
        //             x=Stack[top].x;
        //             y=Stack[top].y-1;
        //             find = 1;
        //             break;
        //         }
        //         break;   //��
        //     }
        // }
        while(di<4 && find==0)      //����һ�����߽��
        {
            di++;
            switch(di)
            {
            case 0:
            if(Stack[top].x-1>=0& find==0){
                x=Stack[top].x-1;
                y=Stack[top].y;
            }
                break;   //����
            case 1:
            if(Stack[top].y+1<maze_row&& find==0){
                x=Stack[top].x;
                y=Stack[top].y+1;
            }
                break;   //�ұ�
            case 2:
            if(Stack[top].x+1<maze_colum&& find==0){
                x=Stack[top].x+1;
                y=Stack[top].y;
            }
                break;   //����
            case 3:
            if(Stack[top].y-1>=0&& find==0){
                x=Stack[top].x;
                y=Stack[top].y-1;
            }
                break;   //���
            }
            if(maze[y][x]=='1')
                find=1;
        }
        if(find == 1)       //�ҵ�����һ�����߽��
        {
            Stack[top].di=di;   //�޸�ԭջ��Ԫ�ص�diֵ
            top++;      //��һ�����߽���ջ
            Stack[top].x=x;
            Stack[top].y=y;
            Stack[top].di=-1;
            maze[y][x]='2';        //�����ظ��ߵ��ý��
        }
        else
        {
            maze[Stack[top].y][Stack[top].x]='1';   //�ø�λ�ñ�Ϊ����·���Ŀ��߽��
            top--;
        }
    }
}
int main()
{
    char *  file_location=NULL;         //����һ���ļ�·���ַ���
    char ** maze;                       //��ά�ַ����飬������ͼ
    file_location = (char*)malloc(sizeof(char)*50); //Ϊ�ļ�·���ַ�������ռ�
    printf("Please input the file path of the maze:\n");
    while(set_OK == 0){
        scanf("%s",file_location);          //�����ļ�����·��������·��
        maze = load_maze(file_location);    //�����Թ�
    }
    mgpath(maze);
    system("pause");
    return 0;
}

char** load_maze(char* file_location){
    FILE *fp=NULL;
    char** maze;
    char tmp = 0;
    int flag = 0;   //Ϊ�˷�ֹ�м���������ֵ��
    int i=0,j=0;
    if((fp = fopen(file_location,"r"))==NULL){
        perror("Faild to load maze");
        return NULL;
    }
    while(!feof(fp)){
        tmp = fgetc(fp);
        if(tmp == '\n'){
            ++maze_row;
            flag = 1;
        }
        if(tmp>=48&&tmp<=57&&flag == 0){
            ++maze_colum;
        }
    }
    rewind(fp); //�ļ�ָ�븴λ
    maze = (char **)malloc(sizeof(char*)*maze_row);

    for(i=0;i<maze_colum;i++){
        maze[i] = (char *)malloc(sizeof(char)*maze_colum);
    }

    i=0;

    while(i<maze_row){
        j=0;
        while(j<maze_colum){
            tmp = fgetc(fp);
            if(tmp <48 || tmp >57) continue;
            maze[i][j] = tmp;
            j++;
        }
        i++;
    }
    printf("maze colum:%d,maze_row:%d\n",maze_colum,maze_row);
        for(i=0;i<maze_row;i++){
            for(j=0;j<maze_colum;j++){
                printf("%c ",maze[i][j]);
            }
        printf("\n");
    }
    printf("Finished loading.\n");
    fclose(fp);
    set_OK = 1;
    return maze;
}
